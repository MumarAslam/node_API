const express = require('express')
const router = express.Router()
var bodyParser = require('body-parser')
router.use(bodyParser.json())
router.use(bodyParser.urlencoded({ extended: true }))
var urlencodedParser = bodyParser.urlencoded({ extended: false })


var listOfObjects = [];

router.get('/', (req, res, next) => {

    res.status(200).json({
        allGame: listOfObjects
    })

})
router.get('/title/:id', (req, res, next) => {
    const size = Object.keys(listOfObjects).length;
    const title = req.params.id
    var index = 0
    var flag = 0
    for (var i = 0; i < size; i++) {
        if (title == listOfObjects[i].title.id) {
            index = i
            flag = 1

        }
    }
    if (flag === 1) {
        res.status(200).json({
            message: listOfObjects[index].title.articles
        })
    }


});
router.get('/:id', (req, res, next) => {
    const size = Object.keys(listOfObjects).length;
    const id = req.params.id
    var index = 0;
    var flag = 0;
    for (var i = 0; i < size; i++) {
        if (id == listOfObjects[i].id) {
            index = i
            flag = 1
        }
    }
    if (flag === 1) {
        res.status(200).json({
            message: listOfObjects[index]
        })
    }

});

router.post('/post', (req, res, next) => {

    let game = {
        id: "",
        name: "",
        title: {
            id: "",
            articles: []

        }
    }

    var id = 1
    if (id === '1') {
        res.status(200).json({
            message: req.body.message,
            id: id
        })
    } else {
        res.status(200).json({
            message: "get",
            id: id

        })
        game.id = req.body.id
        game.name = req.body.name
        game.title.id = req.body.title.id
        game.title.articles = req.body.title.articles
        listOfObjects.push(game)


    }


});

module.exports = router