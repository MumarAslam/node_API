const express = require('express')
const app = express()
const gameRoutes = require('./game/game')
app.use('/game', gameRoutes)
module.exports = app;